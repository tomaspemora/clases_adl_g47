
P = int(input("Ingrese el Precio de suscripción: "))
U = int(input("Ingrese el Número de Usuarios: "))
GT = int(input("Ingrese los Gastos totales: "))
utilidades = P * U - GT
print(f'La utilidad es: {utilidades}')
